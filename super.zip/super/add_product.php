<?php
include('db.php');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $supermarket_id = $_POST['supermarket'];  // تم تعديل هذه القيمة لتأخذ ID المتجر
    $price = $_POST['price'];
    $stock = $_POST['stock'];

    // معالجة رفع الصورة
    $image = $_FILES['image']['name'];
    $image_tmp = $_FILES['image']['tmp_name'];
    $image_path = 'products/' . $image;

    // التحقق من رفع الصورة بنجاح
    if (move_uploaded_file($image_tmp, $image_path)) {
        // إضافة المنتج إلى قاعدة البيانات
        try {
            $stmt = $pdo->prepare("INSERT INTO products (name, supermarket_id, price, stock, image) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $supermarket_id, $price, $stock, $image]);
            echo 'تم إضافة المنتج بنجاح!';
        } catch (PDOException $e) {
            echo 'حدث خطأ أثناء إضافة المنتج: ' . $e->getMessage();
        }
    } else {
        echo 'فشل في رفع الصورة.';
    }
}

// جلب المتاجر من قاعدة البيانات
$supermarkets = $pdo->query("SELECT id, name FROM supermarkets")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إضافة منتج جديد</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;700&display=swap');
        
        * {
            font-family: 'Tajawal', sans-serif;
            transition: all 0.3s ease;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .form-container {
            background: rgba(255, 255, 255, 0.95);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 600px;
            transform: translateY(0);
            animation: formEntrance 0.8s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        }

        @keyframes formEntrance {
            0% { transform: translateY(-50px); opacity: 0; }
            100% { transform: translateY(0); opacity: 1; }
        }

        h1 {
            color: #2d3748;
            text-align: center;
            margin-bottom: 30px;
            font-size: 2.5em;
            position: relative;
        }

        h1::after {
            content: '';
            width: 60px;
            height: 3px;
            background: #667eea;
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
        }

        .form-group {
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #4a5568;
            font-weight: 700;
        }

        input, select, button {
            width: 100%;
            padding: 12px 20px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 16px;
        }

        input:focus, select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            outline: none;
        }

        .input-icon {
            position: relative;
        }

        .input-icon i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #a0aec0;
        }

        button {
            background: #667eea;
            color: white;
            border: none;
            cursor: pointer;
            font-weight: bold;
            padding: 15px;
            margin-top: 15px;
        }

        button:hover {
            background: #764ba2;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        .success-message {
            background: #48bb78;
            color: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: none;
            animation: fadeIn 0.5s;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @media (max-width: 768px) {
            .form-container {
                padding: 20px;
                margin: 15px;
            }
            
            h1 {
                font-size: 1.8em;
            }
        }
    </style>
</head>
<body>
    <div class="form-container animate__animated animate__fadeInDown">
        <h1><i class="fas fa-cube"></i> إضافة منتج جديد</h1>
        
        <div class="success-message" id="successMessage"></div>

        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label><i class="fas fa-tag"></i> اسم المنتج</label>
                <div class="input-icon">
                    <input type="text" name="name" required placeholder="أدخل اسم المنتج">
                </div>
            </div>

            <div class="form-group">
                <label><i class="fas fa-store"></i> المتجر</label>
                <select name="supermarket" required>
                    <?php foreach ($supermarkets as $supermarket): ?>
                        <option value="<?= $supermarket['id'] ?>"><?= $supermarket['name'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label><i class="fas fa-coins"></i> السعر (ر.س)</label>
                <div class="input-icon">
                    <input type="number" name="price" required step="0.01" placeholder="00.00">
                </div>
            </div>

            <div class="form-group">
                <label><i class="fas fa-boxes"></i> الكمية المتاحة</label>
                <div class="input-icon">
                    <input type="number" name="stock" required>
                </div>
            </div>

            <div class="form-group">
                <label><i class="fas fa-image"></i> صورة المنتج</label>
                <input type="file" name="image" required accept="image/*" class="custom-file-input">
            </div>

            <button type="submit" class="animate__animated"><i class="fas fa-plus-circle"></i> إضافة منتج</button>
        </form>
    </div>

    <script>
        document.querySelector('form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // إظهار رسالة النجاح
            const successMessage = document.getElementById('successMessage');
            successMessage.style.display = 'block';
            successMessage.textContent = 'جاري إضافة المنتج...';
            
            // إرسال الفورم بشكل متزامن
            setTimeout(() => {
                this.submit();
                successMessage.textContent = 'تم إضافة المنتج بنجاح!';
                successMessage.style.backgroundColor = '#48bb78';
                
                // إعادة تعيين الفورم بعد 2 ثانية
                setTimeout(() => {
                    this.reset();
                    successMessage.style.display = 'none';
                }, 2000);
            }, 1500);
        });
    </script>
</body>
</html>