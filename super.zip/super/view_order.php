<?php
include('confi.php'); // تأكد من تضمين ملف الاتصال بقاعدة البيانات

// التحقق من وجود معرّف الطلب في الرابط
if (isset($_GET['id'])) {
    $order_id = $_GET['id'];

    // تحضير استعلام لاسترجاع تفاصيل الطلب
    $stmt = $pdo->prepare("SELECT o.order_id, o.total, o.payment_method, o.status, o.created_at, u.name AS customer_name, u.phone, u.address 
                           FROM orders o
                           JOIN users u ON o.user_id = u.user_id
                           WHERE o.order_id = :order_id");
    $stmt->execute(['order_id' => $order_id]);

    // جلب البيانات
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($order) {
        // عرض التفاصيل
        echo "<h1>تفاصيل الطلب رقم " . $order['order_id'] . "</h1>";
        echo "<p>اسم العميل: " . $order['customer_name'] . "</p>";
        echo "<p>رقم الهاتف: " . $order['phone'] . "</p>";
        echo "<p>العنوان: " . $order['address'] . "</p>";
        echo "<p>المبلغ الإجمالي: " . number_format($order['total'], 2) . " ر.س</p>";
        echo "<p>طريقة الدفع: " . $order['payment_method'] . "</p>";
        echo "<p>الحالة: " . $order['status'] . "</p>";
        echo "<p>تاريخ الطلب: " . $order['created_at'] . "</p>";
    } else {
        echo "<p>الطلب غير موجود.</p>";
    }
} else {
    echo "<p>لم يتم تمرير معرّف الطلب.</p>";
}
?>
