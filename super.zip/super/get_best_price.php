<?php
include('config.php');

if(isset($_GET['product'])) {
    $product_name = $_GET['product'];
    $stmt = $conn->prepare("
        SELECT id 
        FROM products 
        WHERE name = ? 
        ORDER BY price ASC 
        LIMIT 1
    ");
    $stmt->bind_param('s', $product_name);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if($result->num_rows > 0) {
        echo json_encode([
            'success' => true,
            'product_id' => $result->fetch_assoc()['id']
        ]);
    } else {
        echo json_encode(['success' => false]);
    }
}
?>