<?php
include('config.php');
session_start();

// التحقق من صلاحيات المستخدم
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT role FROM users WHERE user_id = ?");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if ($user['role'] !== 'admin') {
    header("Location: access_denied.php");
    exit;
}

// الدوال المحسنة
function get_total_products() {
    global $conn;
    $result = $conn->query("SELECT COUNT(*) as total FROM products");
    return $result->fetch_assoc()['total'];
}

function get_total_supermarkets() {
    global $conn;
    $result = $conn->query("SELECT COUNT(*) as total FROM supermarkets");
    return $result->fetch_assoc()['total'];
}

function get_featured_products() {
    global $conn;
    $result = $conn->query("
        SELECT p.*, 
               (SELECT MIN(price) FROM products WHERE name = p.name) as min_price,
               (SELECT COUNT(DISTINCT supermarket_id) FROM products WHERE name = p.name) as market_count
        FROM products p
        GROUP BY p.name
        ORDER BY RAND()
        LIMIT 3
    ");
    return $result->fetch_all(MYSQLI_ASSOC);
}

function get_product_comparison($product_name) {
    global $conn;
    $stmt = $conn->prepare("
        SELECT p.*, 
               s.name as supermarket, 
               s.logo,
               (p.price = (SELECT MIN(price) FROM products WHERE name = ?)) as is_best
        FROM products p
        JOIN supermarkets s ON p.supermarket_id = s.id
        WHERE p.name = ?
        ORDER BY p.price ASC
    ");
    $stmt->bind_param('ss', $product_name, $product_name);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function get_best_price_product_id($product_name) {
    global $conn;
    $stmt = $conn->prepare("
        SELECT id 
        FROM products 
        WHERE name = ? 
        ORDER BY price ASC 
        LIMIT 1
    ");
    $stmt->bind_param('s', $product_name);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc()['id'];
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سوقي - المقارنة الذكية</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
   <style>
         :root {
            --primary: #2A2F4F;
            --secondary: #917FB3;
            --accent: #FFD700;
            --gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        /* تصميم حديث مع تأثيرات ثلاثية الأبعاد */
        .price-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            overflow: hidden;
            position: relative;
            border: 1px solid rgba(0,0,0,0.05);
        }

        .price-card:hover {
            transform: translateY(-10px) rotateX(5deg);
            box-shadow: 0 15px 45px rgba(0,0,0,0.2);
        }

        .best-price-tag {
            position: absolute;
            top: 15px;
            left: -35px;
            background: var(--accent);
            color: #000;
            padding: 8px 40px;
            transform: rotate(-45deg);
            font-weight: bold;
            box-shadow: 0 5px 15px rgba(255,215,0,0.3);
            z-index: 2;
            font-size: 0.9rem;
        }

        .supermarket-logo {
            width: 45px;
            height: 45px;
            object-fit: contain;
            border-radius: 8px;
            padding: 3px;
            background: white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }

        .price-comparison-item {
            background: rgba(255,255,255,0.9);
            border-radius: 12px;
            transition: all 0.3s;
            position: relative;
        }

        .price-comparison-item:hover {
            transform: translateX(10px);
            background: rgba(255,255,255,1);
        }

        .btn-add-best {
            background: linear-gradient(45deg, var(--primary), var(--secondary));
            color: white !important;
            border-radius: 25px;
            padding: 12px 30px;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }

        .btn-add-best::after {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: rgba(255,255,255,0.1);
            transform: rotate(45deg);
            transition: all 0.5s;
        }

        .btn-add-best:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 20px rgba(42,47,79,0.3);
        }

        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
            100% { transform: translateY(0px); }
        }

        .featured-badge {
            animation: float 3s ease-in-out infinite;
        }
</style>
</head>
<body class="bg-light">

<!-- شريط التنقل -->
<nav class="navbar navbar-expand-lg navbar-light nav-glass fixed-top">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">
            <i class="fas fa-balance-scale-left me-2"></i>سوقي
        </a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item mx-2">
                    <a class="nav-link active" href="#home">الرئيسية</a>
                </li>
                <li class="nav-item mx-2">
                    <a class="nav-link" href="#compare">المقارنة</a>
                </li>
                <li class="nav-item mx-2">
                    <a class="nav-link" href="cart.php">
                        <i class="fas fa-shopping-cart"></i> السلة
                        <span class="badge bg-danger"><?= count($_SESSION['cart'] ?? []) ?></span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- قسم المقارنة -->
<section class="py-5" id="compare">
    <div class="container">
        <h2 class="text-center fw-bold mb-5 display-4">🏆 أفضل العروض المميزة</h2>
        
        <div class="row g-4">
            <?php foreach(get_featured_products() as $product): 
                $comparison = get_product_comparison($product['name']);
                $best_product_id = get_best_price_product_id($product['name']);
            ?>
            <div class="col-lg-4 col-md-6">
                <div class="price-card p-4">
                    <?php if($product['price'] == $product['min_price']): ?>
                    <div class="best-price-ribbon">
                        <i class="fas fa-crown"></i> الأفضل
                    </div>
                    <?php endif; ?>
                    
                    <h3 class="fw-bold mb-3 text-center"><?= $product['name'] ?></h3>
                    
                    <div class="price-comparison-chart">
                        <?php foreach($comparison as $item): ?>
                        <div class="price-comparison-item p-3 mb-3 rounded-3 <?= $item['is_best'] ? 'best-price' : '' ?>">
                            <div class="row align-items-center">
                                <div class="col-3">
                                    <img src="logos/<?= $item['logo'] ?>" 
                                         class="supermarket-logo"
                                         alt="<?= $item['supermarket'] ?>">
                                </div>
                                <div class="col-6">
                                    <h5 class="m-0"><?= $item['supermarket'] ?></h5>
                                    <small class="text-muted"><?= date('d/m/Y', strtotime($item['updated_at'])) ?></small>
                                </div>
                                <div class="col-3 text-end">
                                    <div class="price-badge">
                                        <?= number_format($item['price'], 2) ?> ر.س
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="d-grid gap-2">
                        <button class="btn btn-warning" 
                                onclick="addBestToCart('<?= $product['name'] ?>')">
                            <i class="fas fa-cart-plus me-2"></i> أضف الأفضل إلى السلة
                        </button>
                        <small class="text-muted text-center">السعر الأفضل من بين <?= $product['market_count'] ?> متاجر</small>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<script>
// إضافة أفضل سعر تلقائياً
async function addBestToCart(productName) {
    try {
        const response = await fetch('get_best_price.php?product=' + encodeURIComponent(productName));
        const data = await response.json();
        
        if(data.success) {
            addToCart(data.product_id);
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

// وظيفة إضافة إلى السلة مع الرسالة
async function addToCart(productId) {
    try {
        const response = await fetch('add_to_cart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ product_id: productId })
        });
        
        const data = await response.json();
        showToast(data.message);
        updateCartCounter();
    } catch (error) {
        console.error('Error:', error);
    }
}

// تحديث عداد السلة
function updateCartCounter() {
    const counter = document.querySelector('.cart-counter');
    if(counter) {
        counter.textContent = parseInt(counter.textContent) + 1;
    }
}

// عرض الرسالة العائمة
function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.innerHTML = `
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    document.body.appendChild(toast);
    
    setTimeout(() => toast.remove(), 3000);
}
</script>
</body>
</html>