<?php
include('db.php');

// التحقق من وجود المعرف id في الرابط
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // جلب بيانات المتجر من قاعدة البيانات بناءً على id
    $stmt = $pdo->prepare("SELECT * FROM supermarkets WHERE id = ?");
    $stmt->execute([$id]);
    $supermarket = $stmt->fetch(PDO::FETCH_ASSOC);

    // التحقق من وجود المتجر
    if (!$supermarket) {
        echo "المتجر غير موجود.";
        exit;
    }

    // معالجة البيانات عند الإرسال
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $name = $_POST['name'];
        
        // معالجة رفع الشعار
        if ($_FILES['logo']['name']) {
            $logo = $_FILES['logo']['name'];
            $logo_tmp = $_FILES['logo']['tmp_name'];
            $logo_path = 'logos/' . $logo;

            // التحقق من رفع الشعار بنجاح
            if (move_uploaded_file($logo_tmp, $logo_path)) {
                // تحديث المتجر في قاعدة البيانات
                $stmt = $pdo->prepare("UPDATE supermarkets SET name = ?, logo = ? WHERE id = ?");
                $stmt->execute([$name, $logo, $id]);
                echo 'تم تحديث المتجر بنجاح!';
            } else {
                echo 'فشل في رفع الشعار.';
            }
        } else {
            // في حال لم يتم رفع شعار جديد
            $stmt = $pdo->prepare("UPDATE supermarkets SET name = ? WHERE id = ?");
            $stmt->execute([$name, $id]);
            echo 'تم تحديث المتجر بنجاح!';
        }
    }
} else {
    echo "معرف المتجر مفقود.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تعديل بيانات المتجر</title>
</head>
<body>
    <h1>تعديل بيانات المتجر</h1>
    <form method="POST" enctype="multipart/form-data">
        <label>اسم المتجر:</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($supermarket['name']); ?>" required><br>

        <label>شعار المتجر:</label>
        <input type="file" name="logo"><br>
        <img src="logos/<?php echo htmlspecialchars($supermarket['logo']); ?>" alt="Logo" width="100"><br>

        <button type="submit">تحديث المتجر</button>
    </form>
</body>
</html>
