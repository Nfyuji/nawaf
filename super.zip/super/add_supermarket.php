<?php
include('db.php');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    
    // معالجة رفع الشعار
    $logo = $_FILES['logo']['name'];
    $logo_tmp = $_FILES['logo']['tmp_name'];
    $logo_path = 'logos/' . $logo;

    // التحقق من رفع الشعار بنجاح
    if (move_uploaded_file($logo_tmp, $logo_path)) {
        // إضافة المتجر إلى قاعدة البيانات
        try {
            $stmt = $pdo->prepare("INSERT INTO supermarkets (name, logo) VALUES (?, ?)");
            $stmt->execute([$name, $logo]);
            echo 'تم إضافة المتجر بنجاح!';
        } catch (PDOException $e) {
            echo 'حدث خطأ أثناء إضافة المتجر: ' . $e->getMessage();
        }
    } else {
        echo 'فشل في رفع الشعار.';
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إضافة متجر جديد</title>
</head>
<body>
    <h1>إضافة متجر جديد</h1>
    <form method="POST" enctype="multipart/form-data">
        <label>اسم المتجر:</label>
        <input type="text" name="name" required><br>
        
        <label>شعار المتجر:</label>
        <input type="file" name="logo" required><br>

        <button type="submit">إضافة متجر</button>
    </form>
</body>
</html>
