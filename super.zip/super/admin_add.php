<?php 
include('config.php');
// تحقق من صلاحية المدير
if($_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>لوحة التحكم - إضافة منتج</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .admin-panel {
            background: #f8f9fa;
            min-height: 100vh;
        }
        
        .form-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            padding: 2rem;
        }
        
        .form-title {
            border-bottom: 2px solid #eee;
            padding-bottom: 1rem;
            margin-bottom: 2rem;
        }
    </style>
</head>
<body class="admin-panel">
    <div class="container py-5">
        <div class="form-container">
            <h2 class="form-title">📥 إضافة منتج جديد</h2>
            
            <form action="save_product.php" method="POST" enctype="multipart/form-data">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label>اسم المنتج</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    
                    <div class="col-md-6">
                        <label>المتجر</label>
                        <select name="supermarket" class="form-select" required>
                            <?php
                            $query = "SELECT * FROM supermarkets";
                            $result = mysqli_query($conn, $query);
                            while($row = mysqli_fetch_assoc($result)) {
                                echo "<option value='{$row['id']}'>{$row['name']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    
                    <div class="col-md-4">
                        <label>السعر (ريال)</label>
                        <input type="number" step="0.01" name="price" class="form-control" required>
                    </div>
                    
                    <div class="col-md-4">
                        <label>الكمية المتاحة</label>
                        <input type="number" name="stock" class="form-control" required>
                    </div>
                    
                    <div class="col-md-4">
                        <label>الصنف</label>
                        <select name="category" class="form-select" required>
                            <option value="مواد غذائية">مواد غذائية</option>
                            <option value="مشروبات">مشروبات</option>
                            <option value="منظفات">منظفات</option>
                        </select>
                    </div>
                    
                    <div class="col-12">
                        <label>وصف المنتج</label>
                        <textarea name="description" class="form-control" rows="3"></textarea>
                    </div>
                    
                    <div class="col-md-6">
                        <label>صورة المنتج</label>
                        <input type="file" name="image" class="form-control">
                    </div>
                    
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary w-100">حفظ المنتج</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>