<?php
include('db.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // تأكيد الحذف
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // حذف الصورة من الخادم إذا كانت موجودة
        $stmt = $pdo->prepare("SELECT image FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($product && file_exists('products/' . $product['image'])) {
            unlink('products/' . $product['image']);
        }

        // حذف المنتج من قاعدة البيانات
        try {
            $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
            $stmt->execute([$id]);
            echo 'تم حذف المنتج بنجاح!';
            header('Location: admin_products.php'); // إعادة توجيه إلى صفحة قائمة المنتجات
            exit();
        } catch (PDOException $e) {
            echo 'حدث خطأ أثناء حذف المنتج: ' . $e->getMessage();
        }
    }
} else {
    echo 'لم يتم تحديد المنتج.';
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>حذف منتج</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background: #f4f4f9;
            font-family: 'Tajawal', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .confirmation-box {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 100%;
            max-width: 500px;
        }
        .confirmation-box h2 {
            color: #333;
        }
        .confirmation-box p {
            color: #555;
            margin-bottom: 20px;
        }
        button {
            background: #e53e3e;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            margin: 10px;
        }
        button:hover {
            background: #c53030;
        }
        .cancel-btn {
            background: #ddd;
        }
        .cancel-btn:hover {
            background: #bbb;
        }
    </style>
</head>
<body>
    <div class="confirmation-box">
        <h2><i class="fas fa-trash-alt"></i> تأكيد الحذف</h2>
        <p>هل أنت متأكد أنك تريد حذف هذا المنتج؟ هذه العملية لا يمكن التراجع عنها.</p>
        <form method="POST">
            <button type="submit">نعم، حذف المنتج</button>
            <a href="products_list.php" class="cancel-btn button">لا، إلغاء</a>
        </form>
    </div>
</body>
</html>
