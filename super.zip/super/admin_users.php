<?php
include('confi.php'); // تأكد من تضمين ملف الاتصال بقاعدة البيانات

// استعلام لجلب جميع المستخدمين من قاعدة البيانات
$stmt = $pdo->query("SELECT * FROM users ORDER BY created_at DESC");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة المستخدمين</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background-color: #f9fafb;
            font-family: 'Tajawal', sans-serif;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }

        .users-table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .users-table th, .users-table td {
            padding: 15px;
            text-align: center;
            border: 1px solid #ddd;
        }

        .users-table th {
            background-color: #667eea;
            color: white;
        }

        .users-table td {
            color: #555;
        }

        .action-btn {
            background-color: #667eea;
            color: white;
            padding: 8px 15px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        .action-btn:hover {
            background-color: #4c6eb1;
        }

        .delete-btn {
            background-color: #e53e3e;
            color: white;
            border: none;
            padding: 8px 15px;
            cursor: pointer;
            border-radius: 5px;
        }

        .delete-btn:hover {
            background-color: #c53030;
        }

        .add-user-form {
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin: 20px auto;
            width: 50%;
        }

        .add-user-form input, .add-user-form select, .add-user-form button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .add-user-form button {
            background-color: #667eea;
            color: white;
            border: none;
            cursor: pointer;
        }

        .add-user-form button:hover {
            background-color: #4c6eb1;
        }
    </style>
</head>
<body>
    <h1><i class="fas fa-users"></i> إدارة المستخدمين</h1>

    <!-- نموذج إضافة مستخدم جديد -->
    <div class="add-user-form">
        <h3>إضافة مستخدم جديد</h3>
        <form action="add_user.php" method="POST">
            <input type="text" name="name" placeholder="اسم المستخدم" required>
            <input type="email" name="email" placeholder="البريد الإلكتروني" required>
            <input type="password" name="password" placeholder="كلمة المرور" required>
            <select name="role" required>
                <option value="user">مستخدم</option>
                <option value="admin">مشرف</option>
            </select>
            <button type="submit">إضافة المستخدم</button>
        </form>
    </div>

    <!-- جدول عرض المستخدمين -->
    <table class="users-table">
        <thead>
            <tr>
                <th>الاسم</th>
                <th>البريد الإلكتروني</th>
                <th>الدور</th>
                <th>تاريخ الإنشاء</th>
                <th>إجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
            <tr>
                <td><?= $user['name'] ?></td>
                <td><?= $user['email'] ?></td>
                <td><?= $user['role'] == 'admin' ? 'مشرف' : 'مستخدم' ?></td>
                <td><?= $user['created_at'] ?></td>
                <td>
                    <!-- زر تعديل المستخدم -->
                    <a href="edit_user.php?user_id=<?= $user['user_id'] ?>" class="action-btn"><i class="fas fa-edit"></i> تعديل</a>

                    <!-- زر حذف المستخدم -->
                    <form action="delete_user.php" method="POST" style="display:inline;">
                        <input type="hidden" name="user_id" value="<?= $user['user_id'] ?>">
                        <button type="submit" class="delete-btn"><i class="fas fa-trash"></i> حذف</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
