<?php
session_start();
include('config.php');

// التحقق من اتصال قاعدة البيانات
if ($conn->connect_error) {
    die("فشل الاتصال: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // تنقية المدخلات
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];
    
    // التحقق من صحة البيانات
    $errors = [];
    
    if (empty($name)) {
        $errors[] = "الاسم الكامل مطلوب";
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "بريد إلكتروني غير صالح";
    }
    
    if (strlen($password) < 8) {
        $errors[] = "كلمة المرور يجب أن تكون 8 أحرف على الأقل";
    }
    
    // التحقق من وجود البريد مسبقاً
    if (empty($errors)) {
        $check = $conn->prepare("SELECT email FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            $errors[] = "البريد الإلكتروني مسجل مسبقاً";
        }
    }
    
    if (empty($errors)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $hashedPassword);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = "تم إنشاء الحساب بنجاح! يمكنك تسجيل الدخول الآن";
            header("Location: login.php");
            exit();
        } else {
            $errors[] = "حدث خطأ أثناء التسجيل: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل جديد - منصتي</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .auth-card { background: white; border-radius: 10px; box-shadow: 0 0 15px rgba(0,0,0,0.1); }
        .animated-logo { animation: fadeIn 1s ease-in-out; }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    </style>
</head>
<body class="d-flex align-items-center vh-100">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6" data-aos="zoom-in">
                <div class="auth-card p-5 m-3">
                    <div class="text-center mb-5">
                        <img src="logo.svg" class="animated-logo mb-4" width="150" alt="الشعار">
                        <h2 class="fw-bold mb-3 text-primary">انضم إلينا! 🚀</h2>
                        <p class="text-muted">ابدأ رحلتك معنا من خلال إنشاء حساب جديد</p>
                    </div>

                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php foreach ($errors as $error): ?>
                                <div><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
                            <?php endforeach; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" novalidate>
                        <div class="mb-4">
                            <label class="form-label fw-bold">الاسم الكامل</label>
                            <input type="text" name="name" class="form-control form-control-lg" required pattern=".{3,}"
                                   title="يجب أن يحتوي الاسم على 3 أحرف على الأقل"
                                   value="<?= htmlspecialchars($_POST['name'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-bold">البريد الإلكتروني</label>
                            <input type="email" name="email" class="form-control form-control-lg" required
                                   placeholder="example@domain.com"
                                   value="<?= htmlspecialchars($_POST['email'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-bold">كلمة المرور</label>
                            <input type="password" name="password" class="form-control form-control-lg" required minlength="8"
                                   placeholder="••••••••">
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary btn-lg">إنشاء حساب</button>
                        </div>
                    </form>

                    <div class="text-center mt-4">
                        <p class="text-muted">هل لديك حساب بالفعل؟ <a href="login.php" class="fw-bold text-primary">تسجيل الدخول</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script> AOS.init(); </script>
</body>
</html>
