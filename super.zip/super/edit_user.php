<?php
include('confi.php'); // تأكد من تضمين ملف الاتصال بقاعدة البيانات

// جلب بيانات المستخدم لتعديلها
if (isset($_GET['id'])) {
    $user_id = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = :user_id");
    $stmt->execute(['user_id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // التحقق إذا لم يتم العثور على المستخدم
    if (!$user) {
        die("المستخدم غير موجود");
    }
}

// التحقق من البيانات المرسلة لتحديثها
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $role = $_POST['role'];

    // استعلام لتحديث بيانات المستخدم
    $stmt = $pdo->prepare("UPDATE users SET name = :name, email = :email, role = :role WHERE user_id = :user_id");
    $stmt->execute(['name' => $name, 'email' => $email, 'role' => $role, 'user_id' => $user_id]);

    // إعادة التوجيه إلى صفحة المستخدمين بعد التحديث
    header("Location: admin_users.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تعديل بيانات المستخدم</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: 'Tajawal', sans-serif;
            background-color: #f4f7fa;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input, select, button {
            padding: 12px;
            margin: 8px 0;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        input:focus, select:focus, button:focus {
            outline: none;
            border-color: #667eea;
        }
        button {
            background-color: #667eea;
            color: white;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #4c6eb1;
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1><i class="fas fa-user-edit"></i> تعديل بيانات المستخدم</h1>

        <form action="edit_user.php?id=<?= $user['user_id'] ?>" method="POST">
            <label for="name">الاسم:</label>
            <input type="text" id="name" name="name" value="<?= $user['name'] ?>" required>

            <label for="email">البريد الإلكتروني:</label>
            <input type="email" id="email" name="email" value="<?= $user['email'] ?>" required>

            <label for="role">الصلاحية:</label>
            <select id="role" name="role" required>
                <option value="user" <?= $user['role'] == 'user' ? 'selected' : '' ?>>مستخدم</option>
                <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : '' ?>>مشرف</option>
            </select>

            <button type="submit"><i class="fas fa-save"></i> حفظ التغييرات</button>
        </form>
    </div>

</body>
</html>
