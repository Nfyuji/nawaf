<?php
session_start();
include('config.php');

// تحقق من اتصال قاعدة البيانات
if (!$conn) {
    die("فشل الاتصال بقاعدة البيانات: " . mysqli_connect_error());
}

$email = ""; // متغير لحفظ البريد المدخل
$error = ""; // رسالة الخطأ

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];

    // تحقق من القيم الفارغة
    if (empty($email) || empty($password)) {
        $error = "جميع الحقول مطلوبة";
    } else {
        // تعديل الاستعلام ليتم التعامل مع user_id بدلاً من id
        $stmt = $conn->prepare("SELECT user_id, email, password, role FROM users WHERE email = ?");
        
        // التحقق إذا كان الاستعلام قد تم تحضيره بشكل صحيح
        if ($stmt === false) {
            die("خطأ في تحضير الاستعلام: " . $conn->error);
        }

        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            
            // تحقق من كلمة المرور
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['user_id']; // استخدام user_id بدلاً من id
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['role'] = $user['role']; // تخزين الدور بدلاً من admin

                // إعادة توجيه إلى الصفحة الرئيسية
                header("Location: index.php");
                exit();
            } else {
                sleep(1); // تأخير بسيط لمنع هجمات brute-force
            }
        }
        
        // في حال كانت البيانات غير صحيحة
        $error = "البريد الإلكتروني أو كلمة المرور غير صحيحة";
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - منصتي</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <style>
        :root {
            --primary: #6C63FF;
            --secondary: #4A5568;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Tajawal', sans-serif;
        }
        
        .auth-card {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 1.5rem;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }
        
        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(108, 99, 255, 0.25);
        }
        
        .animated-logo {
            animation: float 3s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-15px); }
        }
    </style>
</head>
<body class="d-flex align-items-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6" data-aos="zoom-in">
                <div class="auth-card p-5 m-3">
                    <div class="text-center mb-5">
                        <img src="logo.svg" class="animated-logo mb-4" width="150" alt="الشعار">
                        <h2 class="fw-bold mb-3 text-primary">مرحبا بك مرة أخرى! 👋</h2>
                        <p class="text-muted">الرجاء إدخال بياناتك للوصول إلى حسابك</p>
                    </div>

                    <?php if(!empty($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php endif; ?>

                    <form method="POST" novalidate>
                        <div class="mb-4">
                            <label class="form-label fw-bold">البريد الإلكتروني</label>
                            <input type="email" name="email" class="form-control form-control-lg" 
                                   required
                                   placeholder="example@domain.com"
                                   value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>">
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-bold">كلمة المرور</label>
                            <input type="password" name="password" class="form-control form-control-lg" 
                                   required
                                   placeholder="••••••••">
                        </div>
                        
                        <div class="d-grid mb-4">
                            <button type="submit" class="btn btn-primary btn-lg py-3 fw-bold">
                                تسجيل الدخول
                            </button>
                        </div>
                        
                        <div class="text-center">
                            <a href="forgot-password.php" class="text-decoration-none text-secondary">
                                نسيت كلمة المرور؟
                            </a>
                            <span class="mx-2">|</span>
                            <a href="register.php" class="text-decoration-none text-primary fw-bold">
                                إنشاء حساب جديد
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 1000,
            once: true
        });
    </script>
</body>
</html>
