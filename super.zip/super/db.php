<?php
$host = '127.0.0.1'; // عنوان الخادم
$db   = 'supermarket'; // اسم قاعدة البيانات
$user = 'root'; // اسم المستخدم
$pass = ''; // كلمة المرور

try {
    // إنشاء اتصال PDO
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    // إعداد وضع الخطأ
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // في حال فشل الاتصال
    die("فشل الاتصال: " . $e->getMessage());
}
?>
