<?php 
include('config.php');
// تحقق من صلاحية المدير
if($_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>لوحة التحكم</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <style>
        .dashboard-nav {
            background: #2c3e50;
            min-height: 100vh;
            color: white;
            padding: 20px;
        }
        
        .nav-link {
            color: #bdc3c7 !important;
            transition: all 0.3s;
        }
        
        .nav-link:hover, .nav-link.active {
            color: white !important;
            background: #34495e;
            border-radius: 5px;
        }
        
        .stat-box {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- القائمة الجانبية -->
            <div class="col-md-2 dashboard-nav">
                <h3 class="mb-4">لوحة التحكم</h3>
                <nav class="nav flex-column">
                    <a class="nav-link active" href="admin_dashboard.php">الرئيسية</a>
                    <a class="nav-link" href="admin_add.php">إضافة منتج</a>
                    <a class="nav-link" href="manage_products.php">إدارة المنتجات</a>
                    <a class="nav-link" href="manage_orders.php">الطلبات</a>
                    <a class="nav-link" href="logout.php">تسجيل الخروج</a>
                </nav>
            </div>
            
            <!-- المحتوى الرئيسي -->
            <div class="col-md-10 p-5">
                <h2 class="mb-5">إحصائيات النظام</h2>
                
                <div class="row">
                    <div class="col-md-3">
                        <div class="stat-box">
                            <h5>إجمالي المنتجات</h5>
                            <h3 class="text-primary">
                                <?php 
                                $query = "SELECT COUNT(*) as total FROM products";
                                echo mysqli_fetch_assoc(mysqli_query($conn, $query))['total'];
                                ?>
                            </h3>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="stat-box">
                            <h5>الطلبات النشطة</h5>
                            <h3 class="text-success">
                                <?php 
                                $query = "SELECT COUNT(*) as total FROM orders WHERE status='pending'";
                                echo mysqli_fetch_assoc(mysqli_query($conn, $query))['total'];
                                ?>
                            </h3>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="stat-box">
                            <h5>المستخدمين</h5>
                            <h3 class="text-info">
                                <?php 
                                $query = "SELECT COUNT(*) as total FROM users";
                                echo mysqli_fetch_assoc(mysqli_query($conn, $query))['total'];
                                ?>
                            </h3>
                        </div>
                    </div>
                </div>

                <!-- جدول آخر المنتجات -->
                <h4 class="mt-5 mb-3">آخر المنتجات المضافة</h4>
                <table class="table table-striped" id="productsTable">
                    <thead>
                        <tr>
                            <th>الصورة</th>
                            <th>الاسم</th>
                            <th>السعر</th>
                            <th>المتجر</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = "SELECT p.*, s.name as supermarket 
                                 FROM products p
                                 JOIN supermarkets s ON p.supermarket_id = s.id
                                 ORDER BY p.id DESC LIMIT 5";
                        $result = mysqli_query($conn, $query);
                        
                        while($row = mysqli_fetch_assoc($result)) {
                            echo '<tr>
                                    <td><img src="uploads/'.$row['image'].'" width="50"></td>
                                    <td>'.$row['name'].'</td>
                                    <td>'.$row['price'].' ريال</td>
                                    <td>'.$row['supermarket'].'</td>
                                    <td>
                                        <a href="edit_product.php?id='.$row['id'].'" class="btn btn-sm btn-primary">تعديل</a>
                                        <a href="delete_product.php?id='.$row['id'].'" class="btn btn-sm btn-danger">حذف</a>
                                    </td>
                                  </tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#productsTable').DataTable({
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.11.5/i18n/ar.json'
                }
            });
        });
    </script>
</body>
</html>