<?php
include('db.php');

// التحقق من أن المعرف موجود في الرابط
if (isset($_GET['id'])) {
    $product_id = $_GET['id'];
    
    // استرجاع بيانات المنتج بناءً على المعرف
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // التحقق من وجود المنتج
    if (!$product) {
        echo "المنتج غير موجود.";
        exit;
    }

    // معالجة إرسال النموذج للتحديث
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $name = $_POST['name'];
        $supermarket_id = $_POST['supermarket'];
        $price = $_POST['price'];
        $stock = $_POST['stock'];

        // معالجة رفع الصورة
        $image = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];
        if ($image) {
            $image_path = 'products/' . $image;
            if (move_uploaded_file($image_tmp, $image_path)) {
                // تحديث المنتج في قاعدة البيانات
                $stmt = $pdo->prepare("UPDATE products SET name = ?, supermarket_id = ?, price = ?, stock = ?, image = ? WHERE id = ?");
                $stmt->execute([$name, $supermarket_id, $price, $stock, $image, $product_id]);
                echo 'تم تحديث المنتج بنجاح!';
            } else {
                echo 'فشل في رفع الصورة.';
            }
        } else {
            // في حال لم يتم رفع صورة جديدة، تحديث باقي الحقول فقط
            $stmt = $pdo->prepare("UPDATE products SET name = ?, supermarket_id = ?, price = ?, stock = ? WHERE id = ?");
            $stmt->execute([$name, $supermarket_id, $price, $stock, $product_id]);
            echo 'تم تحديث المنتج بنجاح!';
        }
    }
} else {
    echo "المعرف غير موجود.";
    exit;
}

// جلب المتاجر من قاعدة البيانات
$supermarkets = $pdo->query("SELECT id, name FROM supermarkets")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تعديل المنتج</title>
   
    <style>
         @import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;700&display=swap');
* {
    font-family: 'Tajawal', sans-serif;
    transition: all 0.3s ease;
}

body {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    margin: 0;
    padding: 20px;
    display: flex;
    justify-content: center;
    align-items: center;
}

.form-container {
    background: rgba(255, 255, 255, 0.95);
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    width: 100%;
    max-width: 600px;
    transform: translateY(0);
    animation: formEntrance 0.8s cubic-bezier(0.68, -0.55, 0.265, 1.55);
}

@keyframes formEntrance {
    0% { transform: translateY(-50px); opacity: 0; }
    100% { transform: translateY(0); opacity: 1; }
}

h1 {
    color: #2d3748;
    text-align: center;
    margin-bottom: 30px;
    font-size: 2.5em;
    position: relative;
}

h1::after {
    content: '';
    width: 60px;
    height: 3px;
    background: #667eea;
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
}

.form-group {
    margin-bottom: 25px;
}

label {
    display: block;
    margin-bottom: 8px;
    color: #4a5568;
    font-weight: 700;
}

input, select, button {
    width: 100%;
    padding: 12px 20px;
    border: 2px solid #e2e8f0;
    border-radius: 8px;
    font-size: 16px;
}

input:focus, select:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    outline: none;
}

.input-icon {
    position: relative;
}

.input-icon i {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: #a0aec0;
}

button {
    background: #667eea;
    color: white;
    border: none;
    cursor: pointer;
    font-weight: bold;
    padding: 15px;
    margin-top: 15px;
}

button:hover {
    background: #764ba2;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
}

.success-message {
    background: #48bb78;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: none;
    animation: fadeIn 0.5s;
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

@media (max-width: 768px) {
    .form-container {
        padding: 20px;
        margin: 15px;
    }
    
    h1 {
        font-size: 1.8em;
    }
}

    </style>
</head>
<body>
    <div class="form-container">
        <h1>تعديل المنتج</h1>

        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label>اسم المنتج</label>
                <input type="text" name="name" value="<?= htmlspecialchars($product['name']) ?>" required>
            </div>

            <div class="form-group">
                <label>المتجر</label>
                <select name="supermarket" required>
                    <?php foreach ($supermarkets as $supermarket): ?>
                        <option value="<?= $supermarket['id'] ?>" <?= $supermarket['id'] == $product['supermarket_id'] ? 'selected' : '' ?>><?= $supermarket['name'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>السعر (ر.س)</label>
                <input type="number" name="price" value="<?= htmlspecialchars($product['price']) ?>" required step="0.01">
            </div>

            <div class="form-group">
                <label>الكمية المتاحة</label>
                <input type="number" name="stock" value="<?= htmlspecialchars($product['stock']) ?>" required>
            </div>

            <div class="form-group">
                <label>صورة المنتج</label>
                <input type="file" name="image" accept="image/*">
                <p>الصورة الحالية: <img src="products/<?= htmlspecialchars($product['image']) ?>" alt="منتج" width="100"></p>
            </div>

            <button type="submit">تحديث المنتج</button>
        </form>
    </div>
</body>
</html>
