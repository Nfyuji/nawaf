<?php
session_start();
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['product_id'])) {
    $product_id = intval($_POST['product_id']);
    
    // جلب بيانات المنتج مع اسم المتجر
    $stmt = $conn->prepare("
        SELECT p.*, s.id AS supermarket_id, s.name AS supermarket_name 
        FROM products p
        JOIN supermarkets s ON p.supermarket_id = s.id
        WHERE p.id = ?
    ");
    $stmt->bind_param('i', $product_id);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
    
    if ($product) {
        // التحقق إذا كانت سلة التسوق موجودة
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        $found = false;
        // البحث في السلة للتحقق إذا كان المنتج موجودًا
        foreach ($_SESSION['cart'] as &$item) {
            if ($item['id'] == $product_id) {
                $item['quantity'] += 1; // زيادة الكمية إذا كان المنتج موجودًا
                $found = true;
                break;
            }
        }
        
        // إذا لم يكن المنتج موجودًا في السلة، إضافته
        if (!$found) {
            $_SESSION['cart'][] = [
                'id' => $product_id,
                'name' => $product['name'],
                'price' => $product['price'],
                'quantity' => 1,
                'supermarket_id' => $product['supermarket_id'], // إضافة id للمتجر
                'supermarket' => $product['supermarket_name'] // تخزين اسم المتجر
            ];
        }

        // عرض محتويات السلة بعد الإضافة
        $cart_count = count($_SESSION['cart']);
        $cart_total = 0;
        foreach ($_SESSION['cart'] as $item) {
            $cart_total += $item['price'] * $item['quantity'];
        }

        // استرجاع حالة السلة
        echo json_encode([
            'status' => 'success',
            'cart_count' => $cart_count,
            'cart_total' => $cart_total
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'المنتج غير موجود']);
    }
    exit;
}
?>
