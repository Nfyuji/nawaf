<?php
include('confi.php'); // تأكد من تضمين ملف الاتصال بقاعدة البيانات

// التحقق من وجود معرّف الطلب وحالة الطلب في الطلب POST
if (isset($_POST['order_id']) && isset($_POST['status'])) {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];

    // تأكد من أن الحالة تكون واحدة من القيم المسموح بها
    $valid_statuses = ['pending', 'shipped', 'canceled'];
    if (in_array($status, $valid_statuses)) {
        // استعلام لتحديث حالة الطلب في قاعدة البيانات
        $stmt = $pdo->prepare("UPDATE orders SET status = :status WHERE order_id = :order_id");
        $stmt->execute(['status' => $status, 'order_id' => $order_id]);

        // إظهار رسالة تأكيد
        echo "<p>تم تحديث حالة الطلب بنجاح!</p>";
    } else {
        echo "<p>حالة الطلب غير صالحة.</p>";
    }
} else {
    echo "<p>معرّف الطلب أو الحالة مفقود.</p>";
}
?>
