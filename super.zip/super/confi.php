<?php
// بدء الجلسة
session_start();

// إنشاء اتصال بقاعدة البيانات باستخدام PDO
$host = '127.0.0.1'; // اسم المضيف
$dbname = 'supermarket'; // اسم قاعدة البيانات
$username = 'root'; // اسم المستخدم
$password = ''; // كلمة المرور

try {
    // إنشاء الاتصال بقاعدة البيانات
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // تعيين إعدادات PDO للتحقق من الأخطاء
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // في حال حدوث خطأ في الاتصال بقاعدة البيانات
    echo "Connection failed: " . $e->getMessage();
}
?>
