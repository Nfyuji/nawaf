<?php include('config.php'); ?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <!-- نفس الهيد -->
</head>
<body>
    <div class="container my-5">
        <h2>جهز طلبي</h2>
        
        <form action="submit_order.php" method="POST">
            <div class="mb-3">
                <label>اختر السوبرماركت</label>
                <select name="supermarket" class="form-select">
                    <?php
                    $query = "SELECT * FROM supermarkets";
                    $result = mysqli_query($conn, $query);
                    while($row = mysqli_fetch_assoc($result)) {
                        echo '<option value="'.$row['id'].'">'.$row['name'].'</option>';
                    }
                    ?>
                </select>
            </div>
            
            <div id="productsContainer">
                <div class="product-item mb-3">
                    <select name="products[]" class="form-select">
                        <?php
                        $query = "SELECT * FROM products";
                        $result = mysqli_query($conn, $query);
                        while($row = mysqli_fetch_assoc($result)) {
                            echo '<option value="'.$row['id'].'">'.$row['name'].' - '.$row['price'].' ريال</option>';
                        }
                        ?>
                    </select>
                    <input type="number" name="quantities[]" class="form-control" placeholder="الكمية" min="1" value="1">
                </div>
            </div>
            
            <button type="button" class="btn btn-secondary" onclick="addProduct()">إضافة منتج آخر</button>
            <button type="submit" class="btn btn-primary">تأكيد الطلب</button>
        </form>
    </div>

    <script>
        function addProduct() {
            const container = document.getElementById('productsContainer');
            const newProduct = document.createElement('div');
            newProduct.className = 'product-item mb-3';
            newProduct.innerHTML = `
                <select name="products[]" class="form-select">
                    <?php /* نفس خيارات المنتجات */ ?>
                </select>
                <input type="number" name="quantities[]" class="form-control" placeholder="الكمية" min="1" value="1">
            `;
            container.appendChild(newProduct);
        }
    </script>
</body>
</html>