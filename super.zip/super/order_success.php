<?php
session_start();
include('config.php');

// تأكد من وجود معرّف الطلب في الرابط
$order_id = isset($_GET['id']) ? $_GET['id'] : null;

$success_message = ''; // متغير لتخزين رسالة النجاح

if ($order_id) {
    // استعلام للحصول على تفاصيل الطلب
    $stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?"); // استخدام "order_id" بدلاً من "id"
    if ($stmt === false) {
        die("❌ خطأ في تحضير الاستعلام: " . $conn->error);
    }

    $stmt->bind_param('i', $order_id);
    $stmt->execute();
    
    // تحقق من نجاح الاستعلام
    $result = $stmt->get_result();
    if ($result === false) {
        die("❌ خطأ في تنفيذ الاستعلام: " . $stmt->error);
    }

    // جلب بيانات الطلب
    $order = $result->fetch_assoc();
    if (!$order) {
        die("❌ لم يتم العثور على الطلب.");
    }

    // إذا تم العثور على الطلب، يتم عرض رسالة النجاح
    $success_message = 'تمت العملية بنجاح!';
} else {
    die("❌ لم يتم تحديد معرف الطلب.");
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إتمام العملية</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .success-message {
            display: none;
            padding: 15px;
            background-color: #28a745;
            color: white;
            border-radius: 5px;
            text-align: center;
            margin-top: 20px;
            animation: fadeIn 3s ease-out;
        }

        @keyframes fadeIn {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }
    </style>
</head>
<body>
    <?php include('navbar.php') ?>

    <div class="container py-5">
        <div class="row">
            <div class="col-lg-12">
                <!-- رسالة النجاح عند إتمام العملية -->
                <?php if ($success_message): ?>
                    <div class="success-message" id="successMessage">
                        <?= $success_message ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // إظهار رسالة النجاح مع التأثير الأنيميشن
        window.onload = function() {
            var successMessage = document.getElementById('successMessage');
            if (successMessage) {
                successMessage.style.display = 'block';
            }
        }
    </script>
</body>
</html>
