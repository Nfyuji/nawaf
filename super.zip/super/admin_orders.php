<?php
include('confi.php'); // تأكد من تضمين ملف الاتصال بقاعدة البيانات

// الآن يمكنك استخدام $pdo
$stmt = $pdo->query("SELECT o.order_id, o.total, o.payment_method, o.status, o.created_at, u.name AS customer_name, u.phone, u.address 
                     FROM orders o 
                     JOIN users u ON o.user_id = u.user_id 
                     ORDER BY o.created_at DESC");
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة الطلبات</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background-color: #f9fafb;
            font-family: 'Tajawal', sans-serif;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }

        .orders-table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .orders-table th, .orders-table td {
            padding: 15px;
            text-align: center;
            border: 1px solid #ddd;
        }

        .orders-table th {
            background-color: #667eea;
            color: white;
        }

        .orders-table td {
            color: #555;
        }

        .status-pending {
            background-color: #ffb100;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
        }

        .status-shipped {
            background-color: #48bb78;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
        }

        .status-canceled {
            background-color: #e53e3e;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
        }

        .action-btn {
            background-color: #667eea;
            color: white;
            padding: 8px 15px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        .action-btn:hover {
            background-color: #4c6eb1;
        }

        .update-status-btn {
            background-color: #fbbf24;
            color: white;
            border: none;
            padding: 8px 15px;
            cursor: pointer;
            border-radius: 5px;
        }

        .update-status-btn:hover {
            background-color: #f59e0b;
        }
    </style>
</head>
<body>
    <h1><i class="fas fa-box"></i> إدارة الطلبات</h1>

    <table class="orders-table">
        <thead>
            <tr>
                <th>معرّف الطلب</th>
                <th>اسم العميل</th>
                <th>تاريخ الطلب</th>
                <th>المبلغ الإجمالي (ر.س)</th>
                <th>الحالة</th>
                <th>إجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($orders as $order): ?>
            <tr>
                <td><?= $order['order_id'] ?></td>
                <td><?= $order['customer_name'] ?></td>
                <td><?= $order['created_at'] ?></td>
                <td><?= number_format($order['total'], 2) ?></td>
                <td>
                    <?php 
                    if ($order['status'] == 'pending') {
                        echo '<span class="status-pending">قيد الانتظار</span>';
                    } elseif ($order['status'] == 'shipped') {
                        echo '<span class="status-shipped">تم الشحن</span>';
                    } else {
                        echo '<span class="status-canceled">ملغى</span>';
                    }
                    ?>
                </td>
                <td>
                    <form action="update_order_status.php" method="POST" style="display:inline;">
                        <input type="hidden" name="order_id" value="<?= $order['order_id'] ?>">
                        <select name="status" required>
                            <option value="pending" <?= $order['status'] == 'pending' ? 'selected' : '' ?>>قيد الانتظار</option>
                            <option value="shipped" <?= $order['status'] == 'shipped' ? 'selected' : '' ?>>تم الشحن</option>
                            <option value="canceled" <?= $order['status'] == 'canceled' ? 'selected' : '' ?>>ملغى</option>
                        </select>
                        <button type="submit" class="update-status-btn">تحديث الحالة</button>
                    </form>
                    <a href="view_order.php?id=<?= $order['order_id'] ?>" class="action-btn"><i class="fas fa-eye"></i> عرض التفاصيل</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>