<?php include('config.php'); ?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <!-- نفس ستايل index.php -->
</head>
<body>

<!-- ... نفس الهيدر ... -->

<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h3 class="mb-4">اختر المنتجات</h3>
                <div class="mb-3">
                    <select class="form-select" id="supermarketSelect">
                        <?php
                        $sql = "SELECT * FROM supermarkets";
                        $result = $conn->query($sql);
                        while($row = $result->fetch_assoc()):
                        ?>
                        <option value="<?= $row['id'] ?>"><?= $row['name'] ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div id="productsList" class="mb-4"></div>
                
                <button class="btn btn-success w-100" onclick="submitOrder()">تأكيد الطلب</button>
            </div>
        </div>
    </div>
</section>

<script>
// جلب المنتجات حسب المتجر
document.getElementById('supermarketSelect').addEventListener('change', function() {
    fetch(`get_products.php?supermarket=${this.value}`)
        .then(res => res.text())
        .then(html => {
            document.getElementById('productsList').innerHTML = html;
        });
});

// إرسال الطلب
function submitOrder() {
    const products = [];
    document.querySelectorAll('.product-check:checked').forEach(checkbox => {
        products.push({
            id: checkbox.dataset.id,
            quantity: checkbox.dataset.quantity,
            price: checkbox.dataset.price
        });
    });
    
    // ... إرسال البيانات عبر fetch ...
}
</script>

</body>
</html>