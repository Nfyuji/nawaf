<?php
session_start();
include('config.php');

if (empty($_SESSION['cart'])) {
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $conn->begin_transaction();

        // التحقق من صحة المدخلات
        $name = trim($_POST['name']);
        $phone = trim($_POST['phone']);
        $address = trim($_POST['address']);
        $payment_method = isset($_POST['payment_method']) ? trim($_POST['payment_method']) : '';

        if (empty($name) || empty($phone) || empty($address) || empty($payment_method)) {
            throw new Exception("❌ يجب ملء جميع الحقول وإختيار طريقة الدفع!");
        }

        // الحصول على ID أول متجر في السلة
        $first_item = reset($_SESSION['cart']);
        $supermarket_id = $first_item['supermarket_id'] ?? null;
        if (!$supermarket_id) {
            throw new Exception("❌ لا يوجد متجر محدد للطلب!");
        }

        // حساب المجموع الكلي
        $total = array_sum(array_map(function($item) {
            return $item['price'] * $item['quantity'];
        }, $_SESSION['cart']));

        // إدخال الطلب في جدول `orders`
        $stmt = $conn->prepare("
            INSERT INTO orders 
                (user_id, supermarket_id, total, payment_method, name, phone, address, status, created_at) 
            VALUES 
                (?, ?, ?, ?, ?, ?, ?, 'pending', NOW())
        ");
        if (!$stmt) {
            throw new Exception("❌ خطأ في تحضير استعلام الطلب: " . $conn->error);
        }

        $stmt->bind_param('iisssss', $_SESSION['user_id'], $supermarket_id, $total, $payment_method, $name, $phone, $address);

        if (!$stmt->execute()) {
            throw new Exception("❌ خطأ في إدخال الطلب: " . $stmt->error);
        }

        $order_id = $conn->insert_id;

        // إدخال المنتجات في `order_items`
        $stmt_items = $conn->prepare("
            INSERT INTO order_items 
                (order_id, product_id, quantity, price, supermarket_id) 
            VALUES 
                (?, ?, ?, ?, ?)
        ");
        if (!$stmt_items) {
            throw new Exception("❌ خطأ في تحضير استعلام العناصر: " . $conn->error);
        }

        foreach ($_SESSION['cart'] as $item) {
            $stmt_items->bind_param('iiidi', 
                $order_id, 
                $item['id'], 
                $item['quantity'], 
                $item['price'],
                $item['supermarket_id']
            );

            if (!$stmt_items->execute()) {
                throw new Exception("❌ خطأ في إدخال العنصر: " . $stmt_items->error);
            }
        }

        $conn->commit();
        unset($_SESSION['cart']);
        
        header("Location: order_success.php?id=$order_id");
        exit;

    } catch (Exception $e) {
        $conn->rollback();
        die($e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إتمام الدفع - سوقي</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        function togglePaymentFields() {
            let paymentMethod = document.getElementById("payment_method").value;
            let cardDetails = document.getElementById("card-details");

            if (paymentMethod === "visa" || paymentMethod === "mastercard") {
                cardDetails.style.display = "block";
            } else {
                cardDetails.style.display = "none";
            }
        }

        function validateForm() {
            let name = document.forms["checkoutForm"]["name"].value;
            let phone = document.forms["checkoutForm"]["phone"].value;
            let address = document.forms["checkoutForm"]["address"].value;
            let paymentMethod = document.getElementById("payment_method").value;

            if (name.trim() === "" || phone.trim() === "" || address.trim() === "") {
                alert("يرجى إدخال جميع البيانات المطلوبة.");
                return false;
            }

            if (paymentMethod === "") {
                alert("يرجى اختيار طريقة الدفع.");
                return false;
            }

            if (paymentMethod === "visa" || paymentMethod === "mastercard") {
                let cardNumber = document.forms["checkoutForm"]["card_number"].value;
                let expiryDate = document.forms["checkoutForm"]["expiry_date"].value;
                let cvv = document.forms["checkoutForm"]["cvv"].value;

                if (cardNumber.trim() === "" || expiryDate.trim() === "" || cvv.trim() === "") {
                    alert("يرجى إدخال بيانات البطاقة.");
                    return false;
                }
            }

            return true;
        }
    </script>
</head>
<body>
    <?php include('navbar.php'); ?>

    <div class="container py-5">
        <div class="row">
            <!-- قسم معلومات الدفع -->
            <div class="col-lg-8 mb-4">
                <div class="card shadow">
                    <div class="card-body">
                        <h4 class="mb-4"><i class="fas fa-credit-card me-2"></i>معلومات الدفع</h4>
                        
                        <form name="checkoutForm" method="POST" onsubmit="return validateForm()">
                            <div class="row g-3">
                                <!-- الاسم -->
                                <div class="col-md-6">
                                    <label class="form-label">الاسم الكامل</label>
                                    <input type="text" name="name" class="form-control" required>
                                </div>

                                <!-- رقم الهاتف -->
                                <div class="col-md-6">
                                    <label class="form-label">رقم الهاتف</label>
                                    <input type="text" name="phone" class="form-control" required>
                                </div>

                                <!-- العنوان -->
                                <div class="col-12">
                                    <label class="form-label">العنوان</label>
                                    <textarea name="address" class="form-control" required></textarea>
                                </div>

                                <!-- طريقة الدفع (قائمة منسدلة) -->
                                <div class="col-12">
                                    <label class="form-label">طريقة الدفع</label>
                                    <select id="payment_method" name="payment_method" class="form-select" onchange="togglePaymentFields()" required>
                                        <option value="">اختر طريقة الدفع</option>
                                        <option value="visa">بطاقة فيزا</option>
                                        <option value="mastercard">بطاقة ماستر كارد</option>
                                        <option value="cash">الدفع عند الاستلام</option>
                                    </select>
                                </div>

                                <!-- تفاصيل البطاقة (تظهر فقط عند اختيار فيزا أو ماستر كارد) -->
                                <div id="card-details" class="col-12" style="display: none;">
                                    <h5 class="mt-3">تفاصيل البطاقة</h5>
                                    <div class="mb-2">
                                        <label class="form-label">رقم البطاقة</label>
                                        <input type="text" name="card_number" class="form-control">
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label class="form-label">تاريخ الانتهاء</label>
                                            <input type="text" name="expiry_date" class="form-control" placeholder="MM/YY">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">CVV</label>
                                            <input type="text" name="cvv" class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary w-100 mt-4 py-2">
                                <i class="fas fa-lock me-2"></i>تأكيد الدفع
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- ملخص الطلب -->
            <div class="col-lg-4">
                <div class="card shadow">
                    <div class="card-body">
                        <h5 class="mb-3"><i class="fas fa-receipt me-2"></i>ملخص الطلب</h5>
                        <?php foreach($_SESSION['cart'] as $item): ?>
                        <div class="d-flex justify-content-between mb-2">
                            <span><?= $item['name'] ?> (×<?= $item['quantity'] ?>)</span>
                            <span><?= number_format($item['price'] * $item['quantity'], 2) ?> ر.س</span>
                        </div>
                        <?php endforeach; ?>
                        <hr>
                        <div class="d-flex justify-content-between fw-bold">
                            <span>المجموع الكلي</span>
                            <span class="text-primary">
                                <?= number_format(array_sum(array_map(function($item) {
                                    return $item['price'] * $item['quantity'];
                                }, $_SESSION['cart'])), 2) ?> ر.س
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
