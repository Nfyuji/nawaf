<?php include('config.php'); ?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <!-- نفس ستايل index.php -->
</head>
<body>

<!-- ... نفس الهيدر ... -->

<section class="py-5">
    <div class="container">
        <h3 class="mb-4">نتائج البحث</h3>
        <div class="row">
            <?php
            $search = $conn->real_escape_string($_GET['query']);
            $sql = "SELECT p.*, s.name AS supermarket 
                   FROM products p
                   JOIN supermarkets s ON p.supermarket_id = s.id
                   WHERE p.name LIKE '%$search%'";
            
            $result = $conn->query($sql);
            
            $prices = [];
            while($row = $result->fetch_assoc()) {
                $prices[$row['name']][] = $row;
            }
            
            foreach($prices as $product):
                $minPrice = min(array_column($product, 'price'));
            ?>
            <div class="col-md-6 mb-4">
                <div class="product-card p-3 <?= $product[0]['price'] == $minPrice ? 'best-price' : '' ?>">
                    <h4><?= $product[0]['name'] ?></h4>
                    <?php foreach($product as $item): ?>
                    <div class="d-flex justify-content-between border-bottom py-2">
                        <span><?= $item['supermarket'] ?></span>
                        <span><?= $item['price'] ?> ر.س</span>
                    </div>
                    <?php endforeach; ?>
                    <div class="text-center mt-3">
                        <button class="btn btn-primary">اطلب الآن</button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

</body>
</html>