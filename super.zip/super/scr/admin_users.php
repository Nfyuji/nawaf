<?php
include('config.php');
checkAdminAccess();
$users = getUsers();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة المستخدمين - سوقي</title>
    <!-- نفس الروابط السابقة -->
</head>
<body class="d-flex">
    <?php include('admin_sidebar.php') ?>

    <div class="admin-content p-5 w-100">
        <div class="d-flex justify-content-between mb-4">
            <h3>إدارة المستخدمين</h3>
            <a href="add_user.php" class="btn btn-primary">
                <i class="fas fa-plus me-2"></i>إضافة مستخدم
            </a>
        </div>

        <div class="card shadow">
            <div class="card-body">
                <table class="table table-hover" id="usersTable">
                    <thead class="table-light">
                        <tr>
                            <th>الصورة</th>
                            <th>الاسم</th>
                            <th>البريد</th>
                            <th>الدور</th>
                            <th>التسجيل</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($users as $user): ?>
                        <tr>
                            <td><img src="avatars/<?= $user['avatar'] ?>" width="40" class="rounded-circle"></td>
                            <td><?= $user['name'] ?></td>
                            <td><?= $user['email'] ?></td>
                            <td>
                                <span class="badge bg-<?= $user['role'] == 'admin' ? 'success' : 'primary' ?>">
                                    <?= $user['role'] ?>
                                </span>
                            </td>
                            <td><?= date('Y/m/d', strtotime($user['created_at'])) ?></td>
                            <td>
                                <a href="edit_user.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button onclick="deleteUser(<?= $user['id'] ?>)" class="btn btn-sm btn-danger">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>