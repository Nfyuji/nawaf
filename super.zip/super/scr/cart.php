<?php
session_start();
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['product_id'])) {
    $product_id = intval($_POST['product_id']);
    
    // جلب بيانات المنتج مع اسم المتجر ومعرف المتجر
    $stmt = $conn->prepare("
        SELECT p.*, s.name AS supermarket_name, s.id AS supermarket_id, s.logo AS supermarket_logo 
        FROM products p
        JOIN supermarkets s ON p.supermarket_id = s.id
        WHERE p.id = ?
    ");
    $stmt->bind_param('i', $product_id);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
    
    if ($product) {
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        $found = false;
        foreach ($_SESSION['cart'] as &$item) {
            if ($item['id'] == $product_id) {
                $item['quantity'] += 1;
                $found = true;
                break;
            }
        }
        
        if (!$found) {
            // تحقق من وجود اسم المتجر في البيانات، وإذا كان فارغًا استخدم اسم افتراضي
            $supermarket_name = !empty($product['supermarket_name']) ? $product['supermarket_name'] : 'اسم المتجر غير موجود';
            $_SESSION['cart'][] = [
                'id' => $product_id,
                'name' => $product['name'],
                'price' => $product['price'],
                'quantity' => 1,
                'supermarket' => $supermarket_name, // تخزين اسم المتجر
                'supermarket_id' => $product['supermarket_id'], // تخزين معرف المتجر
                'supermarket_logo' => $product['supermarket_logo'] // تخزين شعار المتجر
            ];
        }
        
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'المنتج غير موجود']);
    }
    function getSupermarketName($conn, $supermarket_id) {
    $stmt = $conn->prepare("SELECT name FROM supermarkets WHERE id = ?");
    $stmt->bind_param("i", $supermarket_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    return $result ? $result['name'] : "متجر غير معروف";
}

    exit;
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>سلة التسوق - سوقي</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2A2F4F;
            --secondary-color: #917FB3;
            --accent-color: #E5BEEC;
        }

        .cart-container {
            background: linear-gradient(45deg, #f8f9fa 0%, #ffffff 100%);
            min-height: 100vh;
        }

        .cart-card {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .product-image {
            width: 100px;
            height: 100px;
            object-fit: contain;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }

        .product-image:hover {
            transform: scale(1.05);
        }

        .quantity-input {
            width: 90px;
            border: 2px solid var(--primary-color);
            border-radius: 10px;
            text-align: center;
        }

        .total-price {
            font-size: 1.5rem;
            color: var(--primary-color);
            font-weight: 700;
        }

        .checkout-btn {
            background: var(--secondary-color);
            border: none;
            padding: 15px 40px;
            border-radius: 15px;
            transition: all 0.3s;
        }

        .checkout-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(145, 127, 179, 0.3);
        }

        .empty-cart {
            height: 60vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }

        .empty-cart i {
            font-size: 5rem;
            color: var(--accent-color);
            margin-bottom: 2rem;
        }
    </style>
</head>
<body class="cart-container">
    <div class="container py-5">
        <h1 class="text-center mb-5 display-4 fw-bold text-primary">
            <i class="fas fa-shopping-cart me-3"></i>سلة التسوق
        </h1>

        <?php if(empty($_SESSION['cart'])): ?>
            <div class="empty-cart">
                <i class="fas fa-cart-arrow-down"></i>
                <h3 class="mb-4">سلة التسوق فارغة</h3>
                <a href="index.php" class="btn btn-lg btn-primary">
                    <i class="fas fa-arrow-left me-2"></i>العودة للتسوق
                </a>
            </div>
        <?php else: ?>
            <div class="cart-card p-4 mb-5">
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>المنتج</th>
                                <th>المتجر</th>
                                <th>السعر</th>
                                <th class="text-center">الكمية</th>
                                <th>المجموع</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $total = 0; 
                            foreach($_SESSION['cart'] as $item): 
                                $total += $item['price'] * $item['quantity'];
                            ?>
                            <tr class="cart-item">
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="products/<?= $item['image'] ?? 'default.png' ?>" 
                                             class="product-image me-3"
                                             alt="<?= $item['name'] ?>">
                                        <h6 class="mb-0"><?= $item['name'] ?></h6>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="logos/<?= $item['supermarket_logo'] ?>" 
                                             width="30" 
                                             class="me-2"
                                             alt="<?= $item['supermarket'] ?>">
                                        <?= $item['supermarket'] ?>
                                    </div>
                                </td>
                                <td><?= number_format($item['price'], 2) ?> ر.س</td>
                                <td class="text-center">
                                    <form method="POST" class="d-inline">
                                        <input type="number" 
                                               name="quantity[<?= $item['id'] ?>]"
                                               value="<?= $item['quantity'] ?>" 
                                               min="1"
                                               class="form-control quantity-input">
                                </td>
                                <td class="fw-bold text-primary">
                                    <?= number_format($item['price'] * $item['quantity'], 2) ?> ر.س
                                </td>
                                <td>
                                    <a href="remove_from_cart.php?id=<?= $item['id'] ?>" 
                                       class="btn btn-link text-danger"
                                       onclick="return confirm('هل تريد حذف هذا المنتج؟')">
                                       <i class="fas fa-trash-alt fa-lg"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="row mt-4">
                    <div class="col-md-6">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="كود الخصم">
                            <button class="btn btn-outline-secondary">تطبيق</button>
                        </div>
                    </div>
                    <div class="col-md-6 text-end">
                        <div class="total-price mb-3">
                            المجموع الكلي: <?= number_format($total, 2) ?> ر.س
                        </div>
                        <div class="d-flex justify-content-end gap-3">
                            <button type="submit" class="btn btn-warning">
                                <i class="fas fa-sync-alt me-2"></i>تحديث السلة
                            </button>
                            </form>
                            <a href="checkout.php" class="btn checkout-btn text-white">
                                <i class="fas fa-credit-card me-2"></i>إتمام الشراء
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
