<?php
include('config.php');
session_start();

// التحقق من إذا كان المستخدم قد سجل الدخول كمسؤول
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");  // إعادة توجيه غير المصرح لهم إلى صفحة تسجيل الدخول
    exit;
}

// جلب بيانات المستخدم بناءً على المعرف
$user_id = $_SESSION['user_id'];
$query = "SELECT role FROM users WHERE user_id = ?";
$stmt = $conn->prepare($query);
if ($stmt === false) {
    die("خطأ في تحضير الاستعلام: " . $conn->error);
}
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result === false) {
    die("خطأ في تنفيذ الاستعلام: " . $conn->error);
}
$user = $result->fetch_assoc();

// التحقق من إذا كان المستخدم لديه دور "admin"
if ($user && $user['role'] !== 'admin') {
    header("Location: access_denied.php");  // إعادة توجيه غير المصرح لهم إلى صفحة عدم الوصول
    exit;
}

// جلب إجمالي المنتجات والمتاجر
$total_products = get_total_products();
$total_supermarkets = get_total_supermarkets();

function get_total_products() {
    global $conn;
    $result = $conn->query("SELECT COUNT(*) as total FROM products");
    if ($result === false) {
        die("خطأ في الاستعلام: " . $conn->error);
    }
    return $result->fetch_assoc()['total'];
}

function get_total_supermarkets() {
    global $conn;
    $result = $conn->query("SELECT COUNT(*) as total FROM supermarkets");
    if ($result === false) {
        die("خطأ في الاستعلام: " . $conn->error);
    }
    return $result->fetch_assoc()['total'];
}

function get_featured_products() {
    global $conn;
    $result = $conn->query("SELECT * FROM products ORDER BY RAND() LIMIT 3");
    if ($result === false) {
        die("خطأ في الاستعلام: " . $conn->error);
    }
    return $result->fetch_all(MYSQLI_ASSOC);
}

function is_best_price($product_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT price, name FROM products WHERE id = ?");
    if ($stmt === false) {
        die("خطأ في تحضير الاستعلام: " . $conn->error);
    }
    $stmt->bind_param('i', $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result === false) {
        die("خطأ في تنفيذ الاستعلام: " . $conn->error);
    }
    $product = $result->fetch_assoc();
    
    $stmt_min = $conn->prepare("SELECT MIN(price) as min FROM products WHERE name = ?");
    if ($stmt_min === false) {
        die("خطأ في تحضير الاستعلام: " . $conn->error);
    }
    $stmt_min->bind_param('s', $product['name']);
    $stmt_min->execute();
    $result_min = $stmt_min->get_result();
    if ($result_min === false) {
        die("خطأ في تنفيذ الاستعلام: " . $conn->error);
    }
    $min_price = $result_min->fetch_assoc()['min'];

    return $product['price'] == $min_price;
}

function get_product_prices($product_name) {
    global $conn;
    $stmt = $conn->prepare("
        SELECT p.*, s.name as supermarket, s.logo 
        FROM products p
        JOIN supermarkets s ON p.supermarket_id = s.id
        WHERE p.name = ?
    ");
    if ($stmt === false) {
        die("خطأ في تحضير الاستعلام: " . $conn->error);
    }
    $stmt->bind_param('s', $product_name);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result === false) {
        die("خطأ في تنفيذ الاستعلام: " . $conn->error);
    }
    return $result->fetch_all(MYSQLI_ASSOC);
}

function get_supermarkets() {
    global $conn;
    $result = $conn->query("SELECT * FROM supermarkets");
    if ($result === false) {
        die("خطأ في الاستعلام: " . $conn->error);
    }
    return $result->fetch_all(MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سوقي - الذكاء في المقارنة</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2A2F4F;
            --secondary-color: #917FB3;
            --accent-color: #E5BEEC;
            --gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .nav-glass {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
        }

        .hero-section {
            background: var(--gradient);
            height: 100vh;
            clip-path: ellipse(100% 65% at 50% 25%);
        }

        .price-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .best-price-badge {
            background: var(--secondary-color);
            clip-path: polygon(0 0, 100% 0, 90% 100%, 0 100%);
        }

        .hover-zoom {
            transition: transform 0.3s;
        }

        .hover-zoom:hover {
            transform: translateY(-10px);
        }

        .dynamic-gradient {
            animation: gradientShift 15s ease infinite;
            background-size: 400% 400%;
        }

        @keyframes gradientShift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .supermarket-logo {
            filter: grayscale(1);
            transition: all 0.3s;
        }

        .supermarket-logo:hover {
            filter: grayscale(0);
            transform: scale(1.1);
        }
    </style>
</head>
<body class="bg-light">

<!-- شريط التنقل -->
<nav class="navbar navbar-expand-lg navbar-light nav-glass fixed-top">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">
            <i class="fas fa-balance-scale-left me-2"></i>سوقي
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item mx-2">
                    <a class="nav-link active" href="#home">الرئيسية</a>
                </li>
                <li class="nav-item mx-2">
                    <a class="nav-link" href="#compare">المقارنة</a>
                </li>
<?php
// التحقق من وجود المستخدم في الجلسة
if (isset($_SESSION['user_id'])):
    // جلب دور المستخدم من قاعدة البيانات
    $user_id = $_SESSION['user_id'];
    $query = "SELECT role FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    
    // التحقق إذا كان المستخدم لديه دور "admin"
    if ($user && $user['role'] == 'admin'): ?>
        <li class="nav-item mx-2">
            <a class="nav-link" href="admin.php">
                <i class="fas fa-cog me-1"></i> لوحة التحكم
            </a>
        </li>
    <?php endif; ?>
<?php endif; ?>

                <li class="nav-item mx-2">
                    <a class="nav-link" href="but.php">السعر الافضل</a>
                </li>
                                <li class="nav-item mx-2">
                    <a class="nav-link" href="cart.php">السله</a>
                </li>
                <li class="nav-item mx-2">
                    <a class="nav-link" href="#contact">اتصل بنا</a>
                </li>
            </ul>
            
            <div class="ms-3">
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="logout.php" class="btn btn-outline-primary">تسجيل الخروج</a>
                <?php else: ?>
                    <a href="login.php" class="btn btn-primary">تسجيل الدخول</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<!-- قسم البطولة -->
<section class="hero-section text-white" id="home">
    <div class="container h-100 d-flex align-items-center">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <h1 class="display-2 fw-bold mb-4">وفر حتى 50% على مشترياتك اليومية</h1>
                <p class="lead mb-5">مقارنة مباشرة بين أكبر المتاجر في المملكة العربية السعودية</p>
                
                <div class="search-container bg-white rounded-pill p-2 shadow-lg mx-auto" style="max-width: 600px;">
                    <div class="input-group">
                        <input type="text" class="form-control border-0 rounded-pill" 
                               placeholder="ابحث عن منتج أو صنف...">
                        <button class="btn btn-primary rounded-pill px-4">
                            <i class="fas fa-search me-2"></i>ابحث الآن
                        </button>
                    </div>
                </div>

                <div class="stats-container mt-5">
                    <div class="row justify-content-center">
                        <div class="col-auto">
                            <div class="stat-box">
                                <h3 class="fw-bold">+<?= get_total_products() ?></h3>
                                <p>منتج متاح</p>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="stat-box">
                                <h3 class="fw-bold"><?= get_total_supermarkets() ?></h3>
                                <p>متجر مشارك</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- قسم مقارنة الأسعار -->
<section class="py-5" id="compare">
    <div class="container">
        <h2 class="text-center fw-bold mb-5">أفضل العروض هذا الأسبوع</h2>
        
        <div class="row g-4">
            <?php foreach(get_featured_products() as $product): ?>
            <div class="col-lg-4 col-md-6">
                <div class="price-card p-4 hover-zoom border rounded-3 shadow-sm">
                    <div class="position-relative">
                        <?php if(is_best_price($product['id'])): ?>
                        <div class="best-price-badge text-white position-absolute top-0 start-0 px-4 py-2">
                            الأفضل
                        </div>
                        <?php endif; ?>
                        
                        <img src="products/<?= $product['image'] ?>" 
                             class="img-fluid rounded-3 mb-3" 
                             alt="<?= $product['name'] ?>">
                    </div>
                    
                    <h4 class="fw-bold mb-3"><?= $product['name'] ?></h4>
                    
                    <div class="price-comparison mb-3">
                        <?php foreach(get_product_prices($product['name']) as $price): ?>
                        <div class="d-flex justify-content-between py-2 border-bottom">
                            <div class="d-flex align-items-center">
                                <img src="logos/<?= $price['logo'] ?>" 
                                     width="30" 
                                     class="me-2" 
                                     alt="<?= $price['supermarket'] ?>">
                                <span><?= $price['supermarket'] ?></span>
                            </div>
                            <div>
                                <span class="<?= $price['is_best'] ? 'fw-bold text-primary' : '' ?>">
                                    <?= $price['price'] ?> ر.س
                                </span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <form method="POST" id="add-to-cart-form-<?= $product['id'] ?>" class="mb-3">
                        <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                        <button type="button" name="add_to_cart" class="btn btn-primary w-100" onclick="addToCart(<?= $product['id'] ?>)">
                            <i class="fas fa-cart-plus me-2"></i> أضف للسلة
                        </button>
                    </form>

                    <div id="cart-message-<?= $product['id'] ?>" class="alert alert-success d-none" role="alert">
                        تم إضافة المنتج إلى السلة بنجاح!
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<script>
    function addToCart(productId) {
        event.preventDefault();
        
        // إرسال الطلب عبر AJAX إلى الملف PHP لمعالجة إضافة المنتج إلى السلة
        var formData = new FormData();
        formData.append('product_id', productId);
        formData.append('add_to_cart', true);

        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'add_to_cart.php', true);
        
        xhr.onload = function() {
            if (xhr.status === 200) {
                // إظهار رسالة تأكيد
                var message = document.getElementById('cart-message-' + productId);
                message.classList.remove('d-none');
                
                // إخفاء الرسالة بعد 3 ثوانٍ
                setTimeout(function() {
                    message.classList.add('d-none');
                }, 3000);
            }
        };
        
        xhr.send(formData);
    }
</script>


<!-- قسم المتاجر -->
<section class="py-5 bg-white" id="stores">
    <div class="container">
        <h2 class="text-center fw-bold mb-5">المتاجر المشاركة</h2>
        
        <div class="row g-4 justify-content-center">
            <?php foreach(get_supermarkets() as $market): ?>
            <div class="col-auto">
                <div class="supermarket-logo p-3 bg-light rounded-3">
                    <img src="logos/<?= $market['logo'] ?>" 
                         width="80" 
                         alt="<?= $market['name'] ?>">
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- الفوتر -->
<footer class="bg-dark text-white py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4">
                <h5 class="fw-bold mb-3">عن سوقي</h5>
                <p>منصة رائدة في مجال مقارنة الأسعار وتوفير أفضل العروض للمستهلكين</p>
            </div>
            <div class="col-md-4">
                <h5 class="fw-bold mb-3">روابط سريعة</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-white text-decoration-none">الشروط والأحكام</a></li>
                    <li><a href="#" class="text-white text-decoration-none">الأسئلة الشائعة</a></li>
                    <li><a href="#" class="text-white text-decoration-none">سياسة الخصوصية</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5 class="fw-bold mb-3">تابعنا</h5>
                <div class="social-icons">
                    <a href="#" class="text-white me-3"><i class="fab fa-twitter fa-lg"></i></a>
                    <a href="#" class="text-white me-3"><i class="fab fa-instagram fa-lg"></i></a>
                    <a href="#" class="text-white"><i class="fab fa-snapchat fa-lg"></i></a>
                </div>
            </div>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // تفعيل التمرير السلس
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // تحديث تلقائي للأسعار
    setInterval(() => {
        fetch('update_prices.php')
            .then(() => location.reload())
    }, 600000);

    // تفعيل تأثيرات التمرير
    window.addEventListener('scroll', () => {
        document.querySelectorAll('.hover-zoom').forEach(el => {
            const rect = el.getBoundingClientRect();
            if(rect.top < window.innerHeight * 0.8) {
                el.style.opacity = '1';
                el.style.transform = 'translateY(0)';
            }
        });
    });
</script>
</body>
</html>


