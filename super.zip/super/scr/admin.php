<?php
session_start();
include('config.php');

// التحقق من تسجيل الدخول وصلاحية المستخدم كـ "admin"
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: index.php"); // إعادة التوجيه إلى الصفحة الرئيسية إذا لم يكن المستخدم "admin"
    exit();
}

// دوال استرجاع البيانات
function get_total_products() {
    global $conn;
    $result = $conn->query("SELECT COUNT(*) as total FROM products");
    return $result->fetch_assoc()['total'];
}

function get_total_users() {
    global $conn;
    $result = $conn->query("SELECT COUNT(*) as total FROM users");
    return $result->fetch_assoc()['total'];
}

function get_active_orders() {
    global $conn;
    $result = $conn->query("SELECT COUNT(*) as total FROM orders WHERE status = 'active'");
    return $result->fetch_assoc()['total'];
}

function get_latest_products() {
    global $conn;
    $result = $conn->query("SELECT p.name, s.name as supermarket, p.price, p.last_updated 
                            FROM products p
                            JOIN supermarkets s ON p.supermarket_id = s.id
                            ORDER BY p.last_updated DESC LIMIT 5");
    return $result->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>لوحة التحكم - سوقي</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <style>
        .admin-sidebar {
            background: #2A2F4F;
            min-height: 100vh;
            color: white;
            width: 280px;
        }
        .admin-content {
            flex: 1;
            background: #f8f9fa;
        }
        .nav-link-admin {
            color: #bdc3c7;
            transition: all 0.3s;
        }
        .nav-link-admin:hover {
            color: white;
            background: #34495e;
        }
        .stat-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
    </style>
</head>
<body class="d-flex">
    <!-- القائمة الجانبية -->
    <div class="admin-sidebar p-3">
        <h3 class="mb-4">لوحة التحكم</h3>
        <nav class="nav flex-column">
            <a class="nav-link-admin active p-3 rounded" href="index.php">الرئيسية</a>
            <a class="nav-link-admin p-3 rounded" href="admin_products.php">إدارة المنتجات</a>
            <a class="nav-link-admin p-3 rounded" href="admin_orders.php">الطلبات</a>
            <a class="nav-link-admin p-3 rounded" href="admin_users.php">المستخدمين</a>
            <a class="nav-link-admin p-3 rounded" href="admin_supermarkets.php">المتاجر</a>
            <a class="nav-link-admin p-3 rounded text-danger" href="logout.php">تسجيل الخروج</a>
        </nav>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="admin-content p-5">
        <h2 class="mb-5">مرحبًا <?= $_SESSION['user']['name'] ?></h2>
        
        <!-- الإحصائيات السريعة -->
        <div class="row g-4 mb-5">
            <div class="col-md-3">
                <div class="stat-card p-4">
                    <h5>إجمالي المنتجات</h5>
                    <h3 class="text-primary"><?= get_total_products() ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card p-4">
                    <h5>الطلبات النشطة</h5>
                    <h3 class="text-success"><?= get_active_orders() ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card p-4">
                    <h5>المستخدمين</h5>
                    <h3 class="text-info"><?= get_total_users() ?></h3>
                </div>
            </div>
        </div>

        <!-- جدول آخر المنتجات -->
        <div class="stat-card p-4">
            <h4 class="mb-4">آخر المنتجات المضافة</h4>
            <table class="table" id="productsTable">
                <thead>
                    <tr>
                        <th>الاسم</th>
                        <th>المتجر</th>
                        <th>السعر</th>
                        <th>آخر تحديث</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach(get_latest_products() as $product): ?>
                    <tr>
                        <td><?= $product['name'] ?></td>
                        <td><?= $product['supermarket'] ?></td>
                        <td><?= $product['price'] ?> ر.س</td>
                        <td><?= $product['last_updated'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#productsTable').DataTable({
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/ar.json'
                }
            });
        });
    </script>
</body>
</html>
