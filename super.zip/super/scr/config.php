<?php
session_start();
$host = '127.0.0.1';
$user = 'root';  // يفضل تغييره إلى مستخدم أكثر أمانًا
$pass = '';  // يفضل تغييره إلى كلمة مرور قوية
$db   = 'supermarket';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("فشل الاتصال: " . $conn->connect_error);
}

// دالة التحقق من المدير

// دالة تحديث الأسعار مع تحديد نسبة التغير
function updatePrices() {
    global $conn;
    $min_change = 0.95; // الحد الأدنى 95% من السعر الأصلي
    $max_change = 1.05; // الحد الأقصى 105% من السعر الأصلي

    $stmt = $conn->prepare("UPDATE products SET price = price * ? WHERE price > 0");
    $random_factor = $min_change + (mt_rand() / mt_getrandmax()) * ($max_change - $min_change);
    $stmt->bind_param("d", $random_factor);
    $stmt->execute();
    $stmt->close();
}

function getProducts() {
    global $conn;
    return $conn->query("
        SELECT p.*, s.name AS supermarket 
        FROM products p
        JOIN supermarkets s ON p.supermarket_id = s.id
    ")->fetch_all(MYSQLI_ASSOC);
}

function getOrders() {
    global $conn;
    return $conn->query("
        SELECT o.*, u.name AS user_name, s.name AS supermarket 
        FROM orders o
        JOIN users u ON o.user_id = u.id
        JOIN supermarkets s ON o.supermarket_id = s.id
    ")->fetch_all(MYSQLI_ASSOC);
}

function getUsers() {
    global $conn;
    return $conn->query("SELECT * FROM users")->fetch_all(MYSQLI_ASSOC);
}

function getSupermarkets() {
    global $conn;
    return $conn->query("
        SELECT s.*, COUNT(p.id) AS products_count 
        FROM supermarkets s
        LEFT JOIN products p ON s.id = p.supermarket_id
        GROUP BY s.id
    ")->fetch_all(MYSQLI_ASSOC);
}

function getStatusColor($status) {
    $colors = [
        'pending' => 'warning',
        'preparing' => 'info',
        'ready' => 'success'
    ];
    return $colors[$status] ?? 'secondary';
}

// دالة إضافة منتج إلى قاعدة البيانات باستخدام mysqli
function addProduct($name, $supermarket, $price, $stock, $image) {
    global $conn;
    
    // تحضير الاستعلام لإضافة منتج
    $stmt = $conn->prepare("INSERT INTO products (name, supermarket, price, stock, image) VALUES (?, ?, ?, ?, ?)");
    
    // ربط المتغيرات مع الاستعلام
    $stmt->bind_param("ssdis", $name, $supermarket, $price, $stock, $image);
    
    // تنفيذ الاستعلام
    if ($stmt->execute()) {
        echo "تم إضافة المنتج بنجاح!";
    } else {
        echo "حدث خطأ أثناء إضافة المنتج: " . $stmt->error;
    }

    // إغلاق الاستعلام
    $stmt->close();
}

$conn->set_charset("utf8mb4");
?>
