<?php
include('config.php');
$products = getProducts();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>إدارة المنتجات - سوقي</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f4f4f4;
        }
        .admin-content {
            background: white;
            border-radius: 10px;
            padding: 20px;
        }
        .action-btns .btn {
            margin: 2px;
            min-width: 80px;
        }
        .table-hover tbody tr:hover {
            background-color: #f8f9fa;
        }
    </style>
</head>
<body class="d-flex">

    <!-- القائمة الجانبية -->
    <div class="admin-sidebar p-3" style="background:#2A2F4F; min-height:100vh; color:white; width:250px;">
        <h3 class="mb-4">لوحة التحكم</h3>
        <nav class="nav flex-column">
            <a class="nav-link text-light" href="admin.php">🏠 الرئيسية</a>
            <a class="nav-link text-light" href="admin_products.php">📦 إدارة المنتجات</a>
            <a class="nav-link text-light" href="admin_orders.php">🛒 الطلبات</a>
            <a class="nav-link text-light" href="admin_users.php">👥 المستخدمين</a>
            <a class="nav-link text-light" href="admin_supermarkets.php">🏬 المتاجر</a>
            <a class="nav-link text-danger" href="logout.php">🚪 تسجيل الخروج</a>
        </nav>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="admin-content p-5 w-100">
        <div class="d-flex justify-content-between mb-4">
            <h3>إدارة المنتجات</h3>
            <a href="add_product.php" class="btn btn-primary">
                <i class="fas fa-plus me-2"></i>إضافة منتج
            </a>
        </div>

        <div class="card shadow">
            <div class="card-body">
                <table class="table table-hover" id="productsTable">
                    <thead class="table-light">
                        <tr>
                            <th>الصورة</th>
                            <th>الاسم</th>
                            <th>المتجر</th>
                            <th>السعر</th>
                            <th>الكمية</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($products as $product): ?>
                        <tr>
                            <td><img src="products/<?= $product['image'] ?>" width="50"></td>
                            <td><?= htmlspecialchars($product['name']) ?></td>
                            <td><?= htmlspecialchars($product['supermarket']) ?></td>
                            <td><?= number_format($product['price'], 2) ?> ر.س</td>
                            <td><?= intval($product['stock']) ?></td>
                            <td class="action-btns">
                                <a href="edit_product.php?id=<?= $product['id'] ?>" class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button onclick="deleteProduct(<?= $product['id'] ?>)" class="btn btn-sm btn-danger">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

    <script>
        function deleteProduct(id) {
            if(confirm('هل أنت متأكد من حذف المنتج؟')) {
                window.location = 'delete_product.php?id=' + id;
            }
        }

        // تفعيل DataTables
        document.addEventListener("DOMContentLoaded", function() {
            let table = new DataTable("#productsTable", {
                responsive: true,
                autoWidth: false,
                language: {
                    url: "//cdn.datatables.net/plug-ins/1.13.6/i18n/Arabic.json"
                }
            });
        });
    </script>

</body>
</html>
