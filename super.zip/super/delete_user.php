<?php
include('confi.php'); // تأكد من تضمين ملف الاتصال بقاعدة البيانات

// تحقق من وجود المعرف في الرابط أو الطلب
if (isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];  // استلام المعرف من النموذج

    // التحقق إذا كان المعرف موجودًا في قاعدة البيانات
    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = :user_id");
    $stmt->execute(['user_id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        // إذا لم يتم العثور على المستخدم
        die("المستخدم غير موجود في قاعدة البيانات");
    }

    // استعلام لحذف المستخدم
    $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = :user_id");
    $stmt->execute(['user_id' => $user_id]);

    // إعادة التوجيه بعد الحذف
    header("Location: admin_users.php");
    exit();
} else {
    die("المعرف غير موجود في الطلب");
}
?>
