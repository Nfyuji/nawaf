<?php
session_start();

// التحقق من أن معرّف المنتج موجود في الرابط
if (isset($_GET['id'])) {
    $product_id = intval($_GET['id']);  // تحويل معرّف المنتج إلى عدد صحيح

    // التحقق إذا كانت سلة التسوق موجودة
    if (isset($_SESSION['cart'])) {
        // البحث في السلة لإيجاد المنتج الذي سيتم إزالته
        foreach ($_SESSION['cart'] as $key => $item) {
            if ($item['id'] == $product_id) {
                // إزالة المنتج من السلة
                unset($_SESSION['cart'][$key]);
                // إعادة ترتيب المصفوفة بعد الإزالة
                $_SESSION['cart'] = array_values($_SESSION['cart']);
                echo json_encode(['status' => 'success', 'message' => 'تم إزالة المنتج من السلة']);
                exit;
            }
        }
        echo json_encode(['status' => 'error', 'message' => 'المنتج غير موجود في السلة']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'سلة التسوق فارغة']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'معرّف المنتج غير موجود']);
}
?>
